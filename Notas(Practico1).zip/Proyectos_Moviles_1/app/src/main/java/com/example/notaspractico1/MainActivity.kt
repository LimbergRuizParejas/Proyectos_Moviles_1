package com.example.notaspractico1

import android.graphics.Color
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    private lateinit var etNota: EditText
    private lateinit var btnGuardar: Button
    private lateinit var btnEditar: Button
    private lateinit var btnEliminar: Button
    private lateinit var btnCambiarColor: Button
    private lateinit var spinnerColores: Spinner
    private lateinit var rvNotas: RecyclerView

    private val notas = mutableListOf<Nota>()
    private val adapter = NotaAdapter(notas) { position -> seleccionarNota(position) }

    private val colores = listOf(
        Color.WHITE, Color.YELLOW, Color.RED, Color.GREEN, Color.BLUE,
        Color.CYAN, Color.MAGENTA, Color.GRAY, Color.LTGRAY, Color.DKGRAY
    )

    private var notaSeleccionada: Int = RecyclerView.NO_POSITION

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        etNota = findViewById(R.id.etNota)
        btnGuardar = findViewById(R.id.btnGuardar)
        btnEditar = findViewById(R.id.btnEditar)
        btnEliminar = findViewById(R.id.btnEliminar)
        btnCambiarColor = findViewById(R.id.btnCambiarColor)
        spinnerColores = findViewById(R.id.spinnerColores)
        rvNotas = findViewById(R.id.rvNotas)

        rvNotas.layoutManager = LinearLayoutManager(this)
        rvNotas.adapter = adapter

        val spinnerAdapter = ArrayAdapter.createFromResource(
            this,
            R.array.colores,
            android.R.layout.simple_spinner_item
        )
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerColores.adapter = spinnerAdapter

        btnGuardar.setOnClickListener {
            val nota = etNota.text.toString()
            if (nota.isNotEmpty()) {
                guardarNota(nota)
                etNota.text.clear() // Limpiar el campo de texto después de guardar
            } else {
                Toast.makeText(this, "Por favor, escribe una nota", Toast.LENGTH_SHORT).show()
            }
        }

        btnEditar.setOnClickListener {
            val nota = etNota.text.toString()
            if (notaSeleccionada != RecyclerView.NO_POSITION && nota.isNotEmpty()) {
                editarNota(notaSeleccionada, nota)
                etNota.text.clear() // Limpiar el campo de texto después de editar
            } else {
                Toast.makeText(this, "Por favor, selecciona una nota y escribe el nuevo contenido", Toast.LENGTH_SHORT).show()
            }
        }

        btnEliminar.setOnClickListener {
            if (notaSeleccionada != RecyclerView.NO_POSITION) {
                eliminarNota(notaSeleccionada)
            } else {
                Toast.makeText(this, "Por favor, selecciona una nota", Toast.LENGTH_SHORT).show()
            }
        }

        btnCambiarColor.setOnClickListener {
            if (notaSeleccionada != RecyclerView.NO_POSITION) {
                cambiarColor(notaSeleccionada)
            } else {
                Toast.makeText(this, "Por favor, selecciona una nota", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun guardarNota(contenido: String) {
        val nota = Nota(contenido, Color.TRANSPARENT)
        notas.add(nota)
        adapter.notifyDataSetChanged()
        Toast.makeText(this, "Nota guardada", Toast.LENGTH_SHORT).show()
    }

    private fun editarNota(posicion: Int, nuevoContenido: String) {
        if (posicion in notas.indices) {
            notas[posicion].contenido = nuevoContenido
            adapter.notifyDataSetChanged()
            Toast.makeText(this, "Nota editada", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "Posición inválida", Toast.LENGTH_SHORT).show()
        }
    }

    private fun eliminarNota(posicion: Int) {
        if (posicion in notas.indices) {
            notas.removeAt(posicion)
            adapter.notifyDataSetChanged()
            Toast.makeText(this, "Nota eliminada", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "Posición inválida", Toast.LENGTH_SHORT).show()
        }
    }

    private fun cambiarColor(position: Int) {
        val colorSeleccionado = when (spinnerColores.selectedItem.toString()) {
            "Blanco" -> Color.WHITE
            "Amarillo" -> Color.YELLOW
            "Rojo" -> Color.RED
            "Verde" -> Color.GREEN
            "Azul" -> Color.BLUE
            "Cian" -> Color.CYAN
            "Magenta" -> Color.MAGENTA
            "Gris" -> Color.GRAY
            "Gris Claro" -> Color.LTGRAY
            "Gris Oscuro" -> Color.DKGRAY
            else -> Color.TRANSPARENT
        }
        notas[position].color = colorSeleccionado
        adapter.notifyDataSetChanged()
        Toast.makeText(this, "Color cambiado", Toast.LENGTH_SHORT).show()
    }

    private fun seleccionarNota(position: Int) {
        notaSeleccionada = position
    }
}
