package com.example.notaspractico1

data class Nota(var contenido: String, var color: Int)
