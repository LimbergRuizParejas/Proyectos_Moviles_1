package com.example.notaspractico1

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class NotaAdapter(
    private val notas: List<Nota>,
    private val onItemClick: (Int) -> Unit
) : RecyclerView.Adapter<NotaAdapter.NotaViewHolder>() {

    var selectedPosition = RecyclerView.NO_POSITION

    inner class NotaViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvContenido: TextView = itemView.findViewById(R.id.tvContenido)

        init {
            itemView.setOnClickListener {
                val previousPosition = selectedPosition
                selectedPosition = adapterPosition
                notifyItemChanged(previousPosition)
                notifyItemChanged(selectedPosition)
                onItemClick(selectedPosition)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): NotaViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_nota, parent, false)
        return NotaViewHolder(view)
    }

    override fun onBindViewHolder(holder: NotaViewHolder, position: Int) {
        val nota = notas[position]
        holder.tvContenido.text = nota.contenido
        holder.itemView.setBackgroundColor(nota.color)
        holder.itemView.isSelected = selectedPosition == position
    }

    override fun getItemCount(): Int {
        return notas.size
    }
}
