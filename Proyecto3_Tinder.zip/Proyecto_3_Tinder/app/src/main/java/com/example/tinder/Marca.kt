package com.example.tinder

data class Marca(
    val nombre: String,
    val fotos: List<String>
)
