package com.example.snakepractico2

import android.graphics.Canvas
import android.graphics.Paint
import kotlin.random.Random

class Comida {
    var posicion: Pair<Float, Float> = Pair(200f, 200f)
    private val tamano = 60f // Tamaño de la comida aumentado

    fun dibujar(canvas: Canvas, pintura: Paint) {
        canvas.drawRect(posicion.first, posicion.second, posicion.first + tamano, posicion.second + tamano, pintura)
    }

    fun reubicar() {
        posicion = Pair(Random.nextFloat() * 800, Random.nextFloat() * 800)
    }
}
