package com.example.snakepractico2

enum class Direccion {
    ARRIBA, ABAJO, IZQUIERDA, DERECHA
}
