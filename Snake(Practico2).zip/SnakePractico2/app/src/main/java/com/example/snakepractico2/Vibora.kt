package com.example.snakepractico2

import android.graphics.Canvas
import android.graphics.Paint

class Vibora {
    private val cuerpo = mutableListOf<Pair<Float, Float>>()
    private var direccion = Direccion.DERECHA
    private val tamanoSegmento = 60f // Tamaño del segmento de la víbora aumentado

    init {
        cuerpo.add(Pair(100f, 100f))
    }

    fun dibujar(canvas: Canvas, pintura: Paint) {
        for (segmento in cuerpo) {
            canvas.drawRect(segmento.first, segmento.second, segmento.first + tamanoSegmento, segmento.second + tamanoSegmento, pintura)
        }
    }

    fun cambiarDireccion(x: Float, y: Float) {
        val cabeza = cuerpo.first()
        val (cabezaX, cabezaY) = cabeza

        val deltaX = x - cabezaX
        val deltaY = y - cabezaY

        if (Math.abs(deltaX) > Math.abs(deltaY)) {
            // Movimiento horizontal
            if (deltaX > 0 && direccion != Direccion.IZQUIERDA) {
                direccion = Direccion.DERECHA
            } else if (deltaX < 0 && direccion != Direccion.DERECHA) {
                direccion = Direccion.IZQUIERDA
            }
        } else {
            // Movimiento vertical
            if (deltaY > 0 && direccion != Direccion.ARRIBA) {
                direccion = Direccion.ABAJO
            } else if (deltaY < 0 && direccion != Direccion.ABAJO) {
                direccion = Direccion.ARRIBA
            }
        }
    }

    fun mover(anchoPantalla: Float, altoPantalla: Float) {
        val cabeza = cuerpo.first()
        val nuevaCabeza = when (direccion) {
            Direccion.ARRIBA -> Pair(cabeza.first, (cabeza.second - tamanoSegmento + altoPantalla) % altoPantalla)
            Direccion.ABAJO -> Pair(cabeza.first, (cabeza.second + tamanoSegmento) % altoPantalla)
            Direccion.IZQUIERDA -> Pair((cabeza.first - tamanoSegmento + anchoPantalla) % anchoPantalla, cabeza.second)
            Direccion.DERECHA -> Pair((cabeza.first + tamanoSegmento) % anchoPantalla, cabeza.second)
        }
        cuerpo.add(0, nuevaCabeza)
        cuerpo.removeAt(cuerpo.size - 1)
    }

    fun crecer() {
        val cola = cuerpo.last()
        cuerpo.add(cola)
    }

    fun verificarColision(): Boolean {
        val cabeza = cuerpo.first()
        return cuerpo.drop(1).any { it == cabeza }
    }

    fun comer(comida: Comida): Boolean {
        val cabeza = cuerpo.first()
        val (cabezaX, cabezaY) = cabeza
        val (comidaX, comidaY) = comida.posicion

        return cabezaX < comidaX + tamanoSegmento &&
                cabezaX + tamanoSegmento > comidaX &&
                cabezaY < comidaY + tamanoSegmento &&
                cabezaY + tamanoSegmento > comidaY
    }
}
