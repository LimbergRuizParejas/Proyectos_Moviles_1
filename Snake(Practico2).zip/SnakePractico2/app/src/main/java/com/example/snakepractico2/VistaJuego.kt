package com.example.snakepractico2

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.os.Handler
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View

class VistaJuego(context: Context, attrs: AttributeSet?) : View(context, attrs) {
    private val vibora = Vibora()
    private val comida = Comida()
    private val pintura = Paint()
    private val manejador = Handler()
    private val retrasoActualizacion = 200L

    init {
        pintura.color = Color.BLACK
        pintura.style = Paint.Style.FILL
        manejador.postDelayed(object : Runnable {
            override fun run() {
                vibora.mover(width.toFloat(), height.toFloat())
                if (vibora.verificarColision()) {
                    // Manejar la colisión (fin del juego)
                } else {
                    if (vibora.comer(comida)) {
                        comida.reubicar()
                        vibora.crecer()
                    }
                    invalidate()
                    manejador.postDelayed(this, retrasoActualizacion)
                }
            }
        }, retrasoActualizacion)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        vibora.dibujar(canvas, pintura)
        comida.dibujar(canvas, pintura)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                vibora.cambiarDireccion(event.x, event.y)
            }
        }
        return true
    }
}
